(() => {
  const boot = () => {
    const config = JSON.parse(document.getElementById('videira-config').textContent);
    const root = config.root.endsWith('/') ? config.root : config.root + '/';
    const status = document.querySelector('[data-cart-status]');
    let returnFocus;
    const show = dialog => {
      if (!dialog || dialog.open) return;
      returnFocus = document.activeElement;
      dialog.showModal();
      document.body.classList.add('dialog-open');
    };
    document.querySelectorAll('dialog').forEach(dialog => {
      dialog.addEventListener('close', () => {
        if (!document.querySelector('dialog[open]')) document.body.classList.remove('dialog-open');
        if (returnFocus?.isConnected) returnFocus.focus();
      });
      dialog.addEventListener('click', event => {
        if (event.target === dialog && !dialog.matches('[data-age-gate]')) {
          const rect = dialog.getBoundingClientRect();
          if (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) dialog.close();
        }
      });
    });
    let statusTimer;
    const report = message => { clearTimeout(statusTimer); status.textContent = message; statusTimer = setTimeout(() => { status.textContent = ''; }, 5000); };
    const initializeCarousels = (scope = document) => {
      scope.querySelectorAll('.wc-section').forEach(section => {
        const row = section.querySelector('.wc-viewport');
        const previous = section.querySelector('[data-carousel-step="-1"]');
        const next = section.querySelector('[data-carousel-step="1"]');
        if (!row || !previous || !next || row.dataset.carouselReady) return;
        row.dataset.carouselReady = 'true';
        const update = () => {
          const maximum = row.scrollWidth - row.clientWidth;
          const overflow = maximum > 1;
          previous.hidden = !overflow;
          next.hidden = !overflow;
          previous.disabled = row.scrollLeft <= 1;
          next.disabled = row.scrollLeft >= maximum - 1;
        };
        row.addEventListener('scroll', update, { passive: true });
        const observer = new ResizeObserver(update);
        observer.observe(row);
        const track = row.querySelector('.wc-track');
        if (track) observer.observe(track);
        update();
      });
    };
    initializeCarousels();
    document.addEventListener('shopify:section:load', event => initializeCarousels(event.target));
    document.addEventListener('click', async event => {
      const close = event.target.closest('[data-dialog-close]');
      if (close) close.closest('dialog')?.close();
      const filter = event.target.closest('[data-filter-open]');
      if (filter) { const panel=document.querySelector('[data-filter-panel]'); if(panel){panel.hidden=!panel.hidden;filter.setAttribute('aria-expanded',String(!panel.hidden));} }
      if(event.target.closest('[data-filter-close]')){const panel=document.querySelector('[data-filter-panel]');if(panel)panel.hidden=true;const trigger=document.querySelector('[data-filter-open]');trigger?.setAttribute('aria-expanded','false');trigger?.focus();}
      const step = event.target.closest('[data-carousel-step]');
      if (step) {
        const row = step.closest('.wc-section').querySelector('.wc-viewport');
        const card = row.querySelector('.sf-wine-card');
        row.scrollBy({ left: ((card?.getBoundingClientRect().width || 225) + 18) * Number(step.dataset.carouselStep), behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth' });
      }
      if (event.target.closest('[data-product-zoom]')) show(document.querySelector('[data-zoom-dialog]'));
      const thumbnail = event.target.closest('[data-product-image]');
      if (thumbnail) setImage(thumbnail.dataset.productImage);
    });
    document.addEventListener('submit', async event => {
      const form = event.target.closest('[data-shopify-add]');
      if (!form) return;
      event.preventDefault();
      const button = form.querySelector('[type="submit"]');
      if (button.disabled) return;
      const localStatus = form.querySelector('[data-add-status]');
      if (localStatus) localStatus.textContent = '';
      button.disabled = true;
      button.setAttribute('aria-busy', 'true');
      let added = false;
      try {
        const response = await fetch(root + 'cart/add.js', { method: 'POST', body: new FormData(form), headers: { Accept: 'application/json' } });
        const data = await response.json();
        if (!response.ok) throw new Error(data.description || config.error);
        added = true;
        report(config.added);
        if (localStatus) localStatus.textContent = config.added;
        window.location.assign(config.cart);
      } catch (error) {
        const message = added ? config.added + ' ' + config.cartError : error.message || config.error;
        report(message);
        if (localStatus) localStatus.textContent = message;
        if (added) window.location.assign(config.cart);
      } finally { button.disabled = false; button.removeAttribute('aria-busy'); }
    });
    let menu, mobile;
    const initializeMenu = () => {
      menu = document.querySelector('[data-menu-toggle]');
      mobile = document.getElementById('vn-mobile');
      if (!menu || !mobile || menu.dataset.menuReady) return;
      menu.dataset.menuReady = 'true';
      menu.addEventListener('click', () => {
        const expanded = menu.getAttribute('aria-expanded') === 'true';
        menu.setAttribute('aria-expanded', String(!expanded));
        mobile.hidden = expanded;
      });
    };
    initializeMenu();
    document.addEventListener('shopify:section:load', initializeMenu);
    document.addEventListener('click', event => {
      if (event.target.closest('#vn-mobile a') && mobile) {
        mobile.hidden = true;
        menu?.setAttribute('aria-expanded', 'false');
      }
    });
    document.addEventListener('toggle', event => {
      const group = event.target;
      if (!group.matches?.('details.nv-nav-group') || !group.open) return;
      document.querySelectorAll('details.nv-nav-group[open]').forEach(other => { if (other !== group) other.open = false; });
    }, true);
    document.addEventListener('keydown', event => {
      if (event.key !== 'Escape') return;
      const panel=document.querySelector('[data-filter-panel]');if(panel&&!panel.hidden){panel.hidden=true;const trigger=document.querySelector('[data-filter-open]');trigger?.setAttribute('aria-expanded','false');trigger?.focus();}
      if (menu?.getAttribute('aria-expanded') === 'true') { mobile.hidden = true; menu.setAttribute('aria-expanded', 'false'); menu.focus(); }
      document.querySelectorAll('.vn-group details[open], details.vn-group[open]').forEach(el => el.open = false);
    });
    document.addEventListener('pointerdown', event => {
      if (!event.target.closest('.vn-header')) {
        if (mobile) mobile.hidden = true;
        menu?.setAttribute('aria-expanded', 'false');
        document.querySelectorAll('.vn-group details[open], details.vn-group[open]').forEach(el => el.open = false);
      }
    });
    document.querySelectorAll('[data-auto-submit]').forEach(select => select.addEventListener('change', () => select.form.requestSubmit()));
    const setImage = url => {
      document.querySelectorAll('.pd-photo-button .pd-original-photo, [data-zoom-dialog] .pd-original-photo').forEach(img => { img.src = url; img.removeAttribute('srcset'); });
    };
    const select = document.getElementById('variant-select');
    const variantData = document.querySelector('[data-product-variants]');
    if (select && variantData) {
      const variants = JSON.parse(variantData.textContent);
      select.addEventListener('change', () => {
        const variant = variants.find(item => String(item.id) === select.value);
        if (!variant) return;
        document.querySelector('[data-product-price]').textContent = variant.price;
        const compare = document.querySelector('[data-product-compare]'); compare.textContent = variant.compare; compare.hidden = !variant.on_sale;
        document.querySelector('[data-product-submit]').disabled = !variant.available;
        document.querySelector('[data-product-button-label]').textContent = variant.available ? config.add : config.soldOut;
        const qty = document.getElementById('product-quantity'); qty.min = variant.min; qty.step = variant.step; qty.value = variant.min;
        if (variant.max) qty.max = variant.max; else qty.removeAttribute('max');
        if (variant.image) setImage(variant.image);
        const url = new URL(location.href); url.searchParams.set('variant', variant.id); history.replaceState({}, '', url);
      });
    }
    const age = document.querySelector('[data-age-gate]');
    if (age) {
      let accepted = false;
      try { accepted = localStorage.getItem('videira-age-ok') === '1' || localStorage.getItem('videira-age-confirmed') === 'yes'; } catch {}
      if (!accepted && !window.Shopify?.designMode) show(age);
      age.addEventListener('cancel', event => event.preventDefault());
      age.querySelector('[data-age-confirm]').addEventListener('click', () => { try { localStorage.setItem('videira-age-ok', '1'); } catch {} age.close(); });
      age.querySelector('[data-age-deny]').addEventListener('click', () => { age.querySelector('[data-age-denied]').hidden = false; age.querySelector('.age-actions').hidden = true; });
    }
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();

